<?php
    include("database.php")
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Bejelentkezés</title>
    <link rel="stylesheet" href="login_regist.css">
</head>
<body>
    
    <header>
        <h2 class="logo">Logo</h2>
        <nav class="navigation">
            <a href="index.php">Főoldal</a>
            <a href="rolunk.html">Rólunk</a>
            <a href="GYIK.html">GYIK</a>
            <a href="elerhetosegek.html">Elérhetőség</a>
            <button class="btnLogin-popup">Regisztrálás</button>
        </nav>
    </header>
        <div class="form-box register">
            <h2>Regisztráció</h2>
            <form action="<?php htmlspecialchars($_SERVER["PHP_SELF"]) ?>" method="post">
                <div class="input-box">
                    <span class="icon">
                        <ion-icon name="person"></ion-icon>
                    </span>
                    <input type="text" required name="username">
                    <label>Felhaszánlónév</label>
                </div>
                <div class="input-box">
                    <span class="icon">
                        <ion-icon name="mail"></ion-icon></span>
                    <input type="email" required name="email">
                    <label>Email</label>
                </div>
                <div class="input-box">
                    <span class="icon"><ion-icon name="lock-closed"></ion-icon></span>
                    <input type="password" required name="password">
                    <label>Jelszó</label>
                </div>
                <div  style="text-align: center;">
                    <label>Kertes ház</label>
                    <input type="radio" name="answer" value="kert" required>
                    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                    <label>Panel ház</label>
                    <input type="radio" name="answer" value="panel" required>
                </div>
                <div class="remember-forgot">
                    <label><input type="checkbox">
                    Elfogadom a feltételeket és kikötéseket</label>
                    
                </div>
                <div style="text-align: center;">
                    <label>
                    <a href="">Biztonsági feltételek elolvasása</a>
                    </label>
                    
                </div>
                <button type="submit" 
                class="btn" name="submit" value="register"> Regisztrálás</button>
                <div class="login-register">
                    <p>Már van fiókod?<a href="login.php" class="login-link"><big>Bejelentkezés</big></a></p>
                </div>
            </form>
        </div>
    </div>

    <script src="login_regist.js"></script>
    <script type="module" src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.esm.js"></script>
<script nomodule src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.js"></script>
</body>
</html>
<?php

    if($_SERVER["REQUEST_METHOD"] == "POST"){
        $username = filter_input(INPUT_POST, "username", FILTER_SANITIZE_SPECIAL_CHARS);
        $password = filter_input(INPUT_POST, "password", FILTER_SANITIZE_SPECIAL_CHARS);
        $email = filter_input(INPUT_POST, "email", FILTER_SANITIZE_SPECIAL_CHARS);
        $kert_van = null;
        $answer = $_POST["answer"];

        if($answer == "kert"){
            $kert_van = $_POST['answer'];
        }
        elseif($answer == "panel"){
            $kert_van = $_POST['answer'];
        }

        $hash = password_hash($password, PASSWORD_DEFAULT);
        $sql = "INSERT INTO users (user, password, email, kert_panel)
                VALUES ('$username', '$hash', '$email', '$kert_van')";

        try{
            mysqli_query($conn, $sql);
            echo"Sikeres regisztráció";
        }
        catch(mysqli_sql_exception){
            echo"Ez a felhasználónév már foglalt";
        }

    }

    mysqli_close($conn);
?>