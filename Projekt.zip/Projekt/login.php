<?php

    include("database.php")

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Bejelentkezés</title>
    <link rel="stylesheet" href="login_regist.css">
</head>
<body>
    
    <header>
        <h2 class="logo">Logo</h2>
        <nav class="navigation">
            <a href="index.php">Főoldal</a>
            <a href="rolunk.html">Rólunk</a>
            <a href="GYIK.html">GYIK</a>
            <a href="elerhetosegek.html">Elérhetőség</a>
            <button class="btnLogin-popup">Bejelentkezés</button>
        </nav>
    </header>

    <div class="wrapper">
        <span class="icon-close">
            <ion-icon name="close"></ion-icon>
        </span>
        <div class="form-box login">
            <h2>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Login</h2> <!-- XDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDD -->
            <form action="<?php htmlspecialchars($_SERVER["PHP_SELF"]) ?>" method="post">
                <div class="input-box">
                    <span class="icon">
                        <ion-icon name="mail"></ion-icon>
                    </span>
                    <input type="email" required name="email">
                    <label>Email</label>
                </div>
                <div class="input-box">
                    <span class="icon">
                        <ion-icon name="lock-closed"></ion-icon></span>
                    <input type="password" required name="password">
                    <label>Password</label>
                </div>
                <!--<div class="remember-forgot">
                    <label><input type="checkbox">
                    Emlékezz rám</label>
                    <a href="#">Elfelejtetted a jelszavad?</a>
                </div>
                -->
                <button type="submit" class="btn">Login</button>
                <div class="login-register">
                    <p>Nincs még felhasználód?<a href="regist.php" class="register-link"><big>Regisztráció</big></a></p>
                </div>
            </form>
        </div>

    <script src="login_regist.js"></script>
    <script type="module" src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.esm.js"></script>
<script nomodule src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.js"></script>
</body>
</html>
<?php
    $email = filter_input(INPUT_POST, "email", FILTER_SANITIZE_SPECIAL_CHARS);

    $sql = "SELECT * FROM users WHERE email = '$email' ";
    $result = mysqli_query($conn, $sql);

    if(mysqli_num_rows($result) > 0){
        header("Location: index.php");
    }
    else{
        echo"Még nem regisztráltál";
    }

    mysqli_close($conn);
?>